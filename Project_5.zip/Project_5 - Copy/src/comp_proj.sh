g++ -Wall ${1}.cpp -o ${1} -lGL -lGLU -lglut libim/libim.a jpeg/libjpeg.a
