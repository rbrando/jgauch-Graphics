//============================================================
//  File:       im_short.cpp
//  Author:     John Gauch
//  Date:       Spring 2009 - Fall 2016
//============================================================

#include "im_short.h"
#include "../jpeg/jpeg.h"
#include "im_pixel.cpp"
